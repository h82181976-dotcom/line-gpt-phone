package com.example.linegptphone;

import android.content.Context;

public class Settings {
    private final SecurePrefs prefs;

    public Settings(Context context) {
        prefs = new SecurePrefs(context);
    }

    public String apiKey() {
        return prefs.loadApiKey();
    }

    public String chatName() {
        return prefs.getString("chat_name", "よ");
    }

    public String model() {
        return prefs.getString("model", "gpt-5.6-sol");
    }

    public String wakeWords() {
        return prefs.getString("wake_words", "@GPT,＠GPT,GPT");
    }

    public String systemPrompt() {
        return prefs.getString(
                "system_prompt",
                "あなたはLINEグループに参加しているAIです。日本語で自然に短く返答してください。" +
                "必要以上に長文にせず、AIであることを隠さないでください。" +
                "ユーザーが『全体メンションして』『全員メンションして』『@Allして』など、" +
                "LINEの全員メンションを明示的に依頼した場合だけ、返信の先頭に [[ALL]] を付けてください。" +
                "それ以外では [[ALL]] を絶対に付けないでください。"
        );
    }

    public void save(String apiKey, String chatName, String model, String wakeWords, String systemPrompt) throws Exception {
        prefs.saveApiKey(apiKey);
        prefs.putString("chat_name", chatName);
        prefs.putString("model", model);
        prefs.putString("wake_words", wakeWords);
        prefs.putString("system_prompt", systemPrompt);
    }
}
