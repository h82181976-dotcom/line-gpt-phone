package com.example.linegptphone;

import java.util.ArrayDeque;
import java.util.Deque;

public class ConversationMemory {
    private static final Deque<String> HISTORY = new ArrayDeque<>();
    private static final int MAX_LINES = 16;

    public static synchronized String snapshot() {
        return String.join("\n", HISTORY);
    }

    public static synchronized void add(String line) {
        HISTORY.addLast(line);
        while (HISTORY.size() > MAX_LINES) HISTORY.removeFirst();
    }
}
