package com.example.linegptphone;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OpenAIClient {
    public interface Callback {
        void onSuccess(String text);
        void onError(String message);
    }

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public OpenAIClient(Context context) {
        this.context = context.getApplicationContext();
    }

    public void generate(String chat, String sender, String text, Callback cb) {
        executor.execute(() -> {
            try {
                Settings s = new Settings(context);
                String key = s.apiKey();
                if (key.isEmpty()) {
                    cb.onError("APIキーが未設定です");
                    return;
                }

                String history = ConversationMemory.snapshot();
                String prompt =
                        s.systemPrompt() +
                        "\n\n対象LINEグループ: " + chat +
                        "\nこれまでの会話:\n" + (history.isEmpty() ? "(なし)" : history) +
                        "\n\n今回:\n" + sender + ": " + text +
                        "\n\n返信本文だけを返してください。";

                JSONObject body = new JSONObject();
                body.put("model", s.model());
                body.put("input", prompt);

                HttpURLConnection conn = (HttpURLConnection)
                        new URL("https://api.openai.com/v1/responses").openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(60000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Authorization", "Bearer " + key);
                conn.setRequestProperty("Content-Type", "application/json");

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }

                int code = conn.getResponseCode();
                InputStream stream = code >= 200 && code < 300
                        ? conn.getInputStream()
                        : conn.getErrorStream();

                String raw = readAll(stream);
                if (code < 200 || code >= 300) {
                    cb.onError("HTTP " + code + ": " + shorten(raw, 500));
                    return;
                }

                JSONObject json = new JSONObject(raw);
                String out = extractOutputText(json).trim();
                if (out.isEmpty()) {
                    cb.onError("応答本文を取得できませんでした");
                    return;
                }

                ConversationMemory.add(sender + ": " + text);
                ConversationMemory.add("AI: " + out);
                cb.onSuccess(out);
            } catch (Exception e) {
                cb.onError(e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        });
    }

    private static String extractOutputText(JSONObject json) {
        StringBuilder sb = new StringBuilder();
        JSONArray output = json.optJSONArray("output");
        if (output == null) return "";
        for (int i = 0; i < output.length(); i++) {
            JSONObject item = output.optJSONObject(i);
            if (item == null) continue;
            JSONArray content = item.optJSONArray("content");
            if (content == null) continue;
            for (int j = 0; j < content.length(); j++) {
                JSONObject part = content.optJSONObject(j);
                if (part == null) continue;
                if ("output_text".equals(part.optString("type"))) {
                    if (sb.length() > 0) sb.append("\n");
                    sb.append(part.optString("text"));
                }
            }
        }
        return sb.toString();
    }

    private static String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        return out.toString(StandardCharsets.UTF_8);
    }

    private static String shorten(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max);
    }
}
