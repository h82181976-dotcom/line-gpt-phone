package com.example.linegptphone;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class LineNotificationListener extends NotificationListenerService {
    private final Map<String, Long> recent = new HashMap<>();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (!"jp.naver.line.android".equals(sbn.getPackageName())) return;

        Notification n = sbn.getNotification();
        Bundle x = n.extras;
        if (x == null) return;

        String title = cs(x.getCharSequence(Notification.EXTRA_TITLE));
        String text = cs(x.getCharSequence(Notification.EXTRA_TEXT));
        String subText = cs(x.getCharSequence(Notification.EXTRA_SUB_TEXT));
        String conv = cs(x.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE));

        if (text.isEmpty()) return;

        Settings s = new Settings(this);
        String target = s.chatName().trim();
        if (target.isEmpty()) return;

        boolean isTarget = title.contains(target) || subText.contains(target) || conv.contains(target);
        if (!isTarget) return;
        if (!containsWakeWord(text, s.wakeWords())) return;

        String fingerprint = title + "|" + text + "|" + conv;
        long now = System.currentTimeMillis();
        Long before = recent.get(fingerprint);
        if (before != null && now - before < 15000) return;
        recent.put(fingerprint, now);
        recent.entrySet().removeIf(e -> now - e.getValue() > 60000);

        String sender = title.isEmpty() ? "参加者" : title;
        boolean explicitAllRequest = isExplicitAllRequest(text);

        new GeminiClient(this).generate(target, sender, text, new GeminiClient.Callback() {
            @Override
            public void onSuccess(String reply) {
                String body = reply == null ? "" : reply.trim();
                boolean marker = body.startsWith("[[ALL]]");
                if (marker) body = body.substring("[[ALL]]".length()).trim();

                // Local explicit intent is a fallback in case the model omits the marker.
                boolean useAll = marker || explicitAllRequest;
                BridgeState.arm(body, useAll);
                try {
                    if (n.contentIntent != null) n.contentIntent.send();
                } catch (Exception ignored) {}
            }

            @Override
            public void onError(String message) {
                // Never post API errors into LINE automatically.
            }
        });
    }

    private boolean containsWakeWord(String text, String csv) {
        String lower = text.toLowerCase(Locale.ROOT);
        for (String w : csv.split(",")) {
            String t = w.trim();
            if (!t.isEmpty() && lower.contains(t.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    private boolean isExplicitAllRequest(String text) {
        String t = text.toLowerCase(Locale.ROOT).replace("＠", "@").replace(" ", "");
        return t.contains("全体メンションして")
                || t.contains("全員メンションして")
                || t.contains("全体にメンションして")
                || t.contains("全員にメンションして")
                || t.contains("@allして")
                || t.contains("@all送って");
    }

    private String cs(CharSequence c) {
        return c == null ? "" : c.toString().trim();
    }
}
