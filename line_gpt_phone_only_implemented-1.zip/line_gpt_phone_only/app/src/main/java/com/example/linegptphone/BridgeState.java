package com.example.linegptphone;

public class BridgeState {
    public static volatile String pendingReply = null;
    public static volatile boolean awaitingLineWindow = false;
    public static volatile boolean mentionAll = false;
    public static volatile int stage = 0;

    public static void arm(String reply, boolean all) {
        pendingReply = reply == null ? "" : reply;
        mentionAll = all;
        awaitingLineWindow = true;
        stage = 0;
    }

    public static void clear() {
        pendingReply = null;
        mentionAll = false;
        awaitingLineWindow = false;
        stage = 0;
    }
}
