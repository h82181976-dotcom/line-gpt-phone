package com.example.linegptphone;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class LineAccessibilityService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastAttempt = 0;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!BridgeState.awaitingLineWindow || BridgeState.pendingReply == null) return;
        if (event == null || !"jp.naver.line.android".contentEquals(event.getPackageName())) return;

        long now = System.currentTimeMillis();
        if (now - lastAttempt < 180) return;
        lastAttempt = now;
        process();
    }

    private void process() {
        if (!BridgeState.awaitingLineWindow || BridgeState.pendingReply == null) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        if (!BridgeState.mentionAll) {
            normalReply(root);
            return;
        }

        allMentionReply(root);
    }

    private void normalReply(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo edit = findEditable(root);
        if (edit == null) return;
        if (!setText(edit, BridgeState.pendingReply)) return;
        schedule(250, () -> {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r != null) clickSend(r);
        });
    }

    // Stages:
    // 0: type '@' to open LINE's mention candidate UI
    // 1: select the real @All / 全員 candidate
    // 2: append the generated body without replacing the mention span
    // 3: send
    private void allMentionReply(AccessibilityNodeInfo root) {
        switch (BridgeState.stage) {
            case 0: {
                AccessibilityNodeInfo edit = findEditable(root);
                if (edit == null) return;
                if (setText(edit, "@")) {
                    BridgeState.stage = 1;
                    schedule(350, this::process);
                }
                break;
            }
            case 1: {
                AccessibilityNodeInfo candidate = findAllMentionCandidate(root);
                if (candidate != null) {
                    AccessibilityNodeInfo click = clickableAncestor(candidate);
                    if (click != null && click.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        BridgeState.stage = 2;
                        schedule(350, this::process);
                    }
                } else {
                    schedule(300, this::process);
                }
                break;
            }
            case 2: {
                AccessibilityNodeInfo edit = findEditable(root);
                if (edit == null) return;
                String body = BridgeState.pendingReply == null ? "" : BridgeState.pendingReply.trim();
                if (!body.isEmpty()) {
                    CharSequence current = edit.getText();
                    int end = current == null ? 0 : current.length();
                    Bundle sel = new Bundle();
                    sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, end);
                    sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, end);
                    edit.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel);

                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("line-gpt-reply", " " + body));
                        edit.performAction(AccessibilityNodeInfo.ACTION_PASTE);
                    }
                }
                BridgeState.stage = 3;
                schedule(300, this::process);
                break;
            }
            case 3:
                clickSend(root);
                break;
            default:
                BridgeState.clear();
        }
    }

    private AccessibilityNodeInfo findAllMentionCandidate(AccessibilityNodeInfo root) {
        List<String> exact = Arrays.asList("@All", "All", "@all", "all", "全員", "全員にメンション");
        AccessibilityNodeInfo found = findExactText(root, exact);
        if (found != null) return found;

        // Fallback for LINE variants that expose a content description instead of visible text.
        return findDescriptionContaining(root, Arrays.asList("@all", "all", "全員"));
    }

    private AccessibilityNodeInfo findExactText(AccessibilityNodeInfo node, List<String> values) {
        CharSequence cs = node.getText();
        if (cs != null && node.isVisibleToUser()) {
            String t = cs.toString().trim();
            for (String v : values) {
                if (t.equalsIgnoreCase(v)) return node;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            AccessibilityNodeInfo hit = findExactText(child, values);
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo findDescriptionContaining(AccessibilityNodeInfo node, List<String> needles) {
        CharSequence cs = node.getContentDescription();
        if (cs != null && node.isVisibleToUser()) {
            String t = cs.toString().toLowerCase(Locale.ROOT);
            for (String n : needles) {
                if (t.contains(n.toLowerCase(Locale.ROOT))) return node;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            AccessibilityNodeInfo hit = findDescriptionContaining(child, needles);
            if (hit != null) return hit;
        }
        return null;
    }

    private void clickSend(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo send = findClickableText(root, "送信");
        if (send == null) send = findClickableText(root, "Send");
        if (send == null) send = findByDescription(root, "送信");
        if (send == null) send = findByDescription(root, "send");

        if (send != null && send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            BridgeState.clear();
        }
    }

    private boolean setText(AccessibilityNodeInfo edit, String text) {
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    private void schedule(long millis, Runnable r) {
        handler.postDelayed(r, millis);
    }

    @Override
    public void onInterrupt() {}

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo node) {
        if (node.isVisibleToUser() && node.isEditable()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            AccessibilityNodeInfo hit = findEditable(child);
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo findClickableText(AccessibilityNodeInfo root, String text) {
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(text);
        if (nodes == null) return null;
        for (AccessibilityNodeInfo n : nodes) {
            AccessibilityNodeInfo c = clickableAncestor(n);
            if (c != null && c.isVisibleToUser()) return c;
        }
        return null;
    }

    private AccessibilityNodeInfo clickableAncestor(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 5 && cur != null; i++) {
            if (cur.isClickable()) return cur;
            cur = cur.getParent();
        }
        return null;
    }

    private AccessibilityNodeInfo findByDescription(AccessibilityNodeInfo node, String needle) {
        CharSequence d = node.getContentDescription();
        if (d != null && node.isVisibleToUser() && node.isClickable()
                && d.toString().toLowerCase(Locale.ROOT).contains(needle.toLowerCase(Locale.ROOT))) {
            return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            AccessibilityNodeInfo hit = findByDescription(child, needle);
            if (hit != null) return hit;
        }
        return null;
    }
}
