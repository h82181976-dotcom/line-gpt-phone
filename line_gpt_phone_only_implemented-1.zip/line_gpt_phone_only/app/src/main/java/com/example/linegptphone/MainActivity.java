package com.example.linegptphone;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText apiKey, chatName, model, wakeWords, systemPrompt;
    private TextView status;
    private com.example.linegptphone.Settings appSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appSettings = new com.example.linegptphone.Settings(this);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("LINE GPT Phone");
        title.setTextSize(24);
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText(
                "スマホ単体・Google Gemini無料枠版。APIキーは端末のAndroid Keystoreで暗号化して保存します。\n" +
                "無料枠では送信内容がGoogleの製品改善に使われる場合があります。"
        );
        root.addView(desc);

        apiKey = field(root, "Gemini APIキー", "", true);
        chatName = field(root, "対象グループ", appSettings.chatName(), false);
        model = field(root, "モデル", appSettings.model(), false);
        wakeWords = field(root, "呼び出し語（カンマ区切り）", appSettings.wakeWords(), false);
        systemPrompt = field(root, "AIの振る舞い", appSettings.systemPrompt(), false);
        systemPrompt.setMinLines(4);

        String savedKey = appSettings.apiKey();
        if (!savedKey.isEmpty()) apiKey.setHint("保存済み（変更するときだけ入力）");

        Button createKey = new Button(this);
        createKey.setText("無料のGemini APIキーを作成");
        createKey.setOnClickListener(v -> startActivity(new Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://aistudio.google.com/apikey")
        )));
        root.addView(createKey);

        Button save = new Button(this);
        save.setText("設定を保存");
        save.setOnClickListener(v -> saveSettings());
        root.addView(save);

        Button notificationAccess = new Button(this);
        notificationAccess.setText("通知へのアクセスを開く");
        notificationAccess.setOnClickListener(v ->
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));
        root.addView(notificationAccess);

        Button accessibility = new Button(this);
        accessibility.setText("ユーザー補助設定を開く");
        accessibility.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility);

        Button test = new Button(this);
        test.setText("Gemini接続テスト");
        test.setOnClickListener(v -> testGemini());
        root.addView(test);

        status = new TextView(this);
        status.setText("設定後、「よ」のLINE通知をONにし、別の参加者から @GPT こんにちは と送ってテストしてください。");
        status.setPadding(0, dp(12), 0, dp(12));
        root.addView(status);

        setContentView(scroll);
    }

    private EditText field(LinearLayout root, String label, String value, boolean secret) {
        TextView l = new TextView(this);
        l.setText(label);
        l.setPadding(0, dp(12), 0, 0);
        root.addView(l);

        EditText e = new EditText(this);
        e.setText(value);
        if (secret) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        }
        root.addView(e, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        return e;
    }

    private void saveSettings() {
        try {
            String key = apiKey.getText().toString().trim();
            if (key.isEmpty()) key = appSettings.apiKey();
            if (key.isEmpty()) {
                toast("APIキーを入力してください");
                return;
            }
            appSettings.save(
                    key,
                    chatName.getText().toString().trim(),
                    model.getText().toString().trim(),
                    wakeWords.getText().toString().trim(),
                    systemPrompt.getText().toString().trim()
            );
            apiKey.setText("");
            apiKey.setHint("保存済み");
            status.setText("保存しました。通知アクセスとユーザー補助をONにしてください。");
        } catch (Exception e) {
            status.setText("保存エラー: " + e.getMessage());
        }
    }

    private void testGemini() {
        saveSettings();
        status.setText("接続テスト中…");
        new GeminiClient(this).generate(
                "テスト",
                "ユーザー",
                "@GPT 「接続成功」とだけ返して",
                new GeminiClient.Callback() {
                    @Override public void onSuccess(String text) {
                        runOnUiThread(() -> status.setText("Gemini応答: " + text));
                    }
                    @Override public void onError(String message) {
                        runOnUiThread(() -> status.setText("接続失敗: " + message));
                    }
                }
        );
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
