package com.example.linegptphone;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GeminiClient {
    public interface Callback {
        void onSuccess(String text);
        void onError(String message);
    }

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public GeminiClient(Context context) {
        this.context = context.getApplicationContext();
    }

    public void generate(String chat, String sender, String text, Callback cb) {
        executor.execute(() -> {
            try {
                Settings s = new Settings(context);
                String key = s.apiKey();
                if (key.isEmpty()) {
                    cb.onError("Gemini APIキーが未設定です");
                    return;
                }

                String model = s.model().trim();
                if (!model.matches("[A-Za-z0-9._-]+")) {
                    cb.onError("モデル名が不正です");
                    return;
                }

                String history = ConversationMemory.snapshot();
                String prompt =
                        s.systemPrompt() +
                        "\n\n対象LINEグループ: " + chat +
                        "\nこれまでの会話:\n" + (history.isEmpty() ? "(なし)" : history) +
                        "\n\n今回:\n" + sender + ": " + text +
                        "\n\n返信本文だけを返してください。";

                JSONObject userPart = new JSONObject().put("text", prompt);
                JSONObject userContent = new JSONObject()
                        .put("role", "user")
                        .put("parts", new JSONArray().put(userPart));

                JSONObject generationConfig = new JSONObject()
                        .put("temperature", 0.7)
                        .put("maxOutputTokens", 512);

                JSONObject body = new JSONObject()
                        .put("contents", new JSONArray().put(userContent))
                        .put("generationConfig", generationConfig);

                HttpURLConnection conn = (HttpURLConnection) new URL(
                        "https://generativelanguage.googleapis.com/v1beta/models/" +
                                model + ":generateContent"
                ).openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(60000);
                conn.setDoOutput(true);
                conn.setRequestProperty("x-goog-api-key", key);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }

                int code = conn.getResponseCode();
                InputStream stream = code >= 200 && code < 300
                        ? conn.getInputStream()
                        : conn.getErrorStream();

                String raw = readAll(stream);
                if (code < 200 || code >= 300) {
                    cb.onError("HTTP " + code + ": " + extractError(raw));
                    return;
                }

                JSONObject json = new JSONObject(raw);
                String out = extractOutputText(json).trim();
                if (out.isEmpty()) {
                    String reason = extractBlockReason(json);
                    cb.onError(reason.isEmpty()
                            ? "応答本文を取得できませんでした"
                            : "応答がブロックされました: " + reason);
                    return;
                }

                ConversationMemory.add(sender + ": " + text);
                ConversationMemory.add("AI: " + out);
                cb.onSuccess(out);
            } catch (Exception e) {
                cb.onError(e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        });
    }

    private static String extractOutputText(JSONObject json) {
        StringBuilder sb = new StringBuilder();
        JSONArray candidates = json.optJSONArray("candidates");
        if (candidates == null) return "";

        for (int i = 0; i < candidates.length(); i++) {
            JSONObject candidate = candidates.optJSONObject(i);
            if (candidate == null) continue;
            JSONObject content = candidate.optJSONObject("content");
            if (content == null) continue;
            JSONArray parts = content.optJSONArray("parts");
            if (parts == null) continue;

            for (int j = 0; j < parts.length(); j++) {
                JSONObject part = parts.optJSONObject(j);
                if (part == null) continue;
                String value = part.optString("text", "");
                if (value.isEmpty()) continue;
                if (sb.length() > 0) sb.append("\n");
                sb.append(value);
            }
        }
        return sb.toString();
    }

    private static String extractBlockReason(JSONObject json) {
        JSONObject feedback = json.optJSONObject("promptFeedback");
        if (feedback != null) {
            String reason = feedback.optString("blockReason", "");
            if (!reason.isEmpty()) return reason;
        }

        JSONArray candidates = json.optJSONArray("candidates");
        if (candidates != null && candidates.length() > 0) {
            JSONObject candidate = candidates.optJSONObject(0);
            if (candidate != null) return candidate.optString("finishReason", "");
        }
        return "";
    }

    private static String extractError(String raw) {
        try {
            JSONObject error = new JSONObject(raw).optJSONObject("error");
            if (error != null) {
                String message = error.optString("message", "");
                if (!message.isEmpty()) return shorten(message, 500);
            }
        } catch (Exception ignored) {
        }
        return shorten(raw, 500);
    }

    private static String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        return out.toString(StandardCharsets.UTF_8);
    }

    private static String shorten(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max);
    }
}
