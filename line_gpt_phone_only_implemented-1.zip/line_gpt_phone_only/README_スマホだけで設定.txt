LINE GPT Phone - Gemini無料枠版（v0.3）

この版はPC中継サーバーもOpenAIの有料APIも使いません。
Google Gemini APIの無料枠をAndroid端末から直接利用します。

仕組み:
LINE通知
→ このAndroidアプリ
→ Google Gemini API
→ LINEアプリを開く
→ ユーザー補助機能で返信を入力・送信

初期設定:
対象グループ: よ
モデル: gemini-3.5-flash-lite
呼び出し: @GPT / ＠GPT / GPT

重要:
・Google AI Studioの無料枠はカード登録なしで開始できます。
・無料枠には利用回数などの上限があります。
・無料枠で送信した内容はGoogleの製品改善に利用される場合があります。
・APIキーを他人へ送ったり、公開場所へ貼ったりしないでください。
・これはLINE OpenChat向けの公式Bot APIではありません。
・LINEアプリのUI変更により、自動入力/送信部分が壊れる可能性があります。

アプリをインストールした後:
1. 以前のOpenAI版を使っている場合は、そのアプリの通知アクセスとユーザー補助をOFFにしてアンインストール。
2. 新しいAPKをインストールし、「LINE GPT Phone」を開く。
3. 「無料のGemini APIキーを作成」を押す。
4. GoogleアカウントでGoogle AI Studioにログインし、APIキーを作成してコピー。
5. アプリへ戻り、「Gemini APIキー」欄へ貼り付ける。
6. 対象グループが「よ」、モデルが「gemini-3.5-flash-lite」になっていることを確認。
7. 「設定を保存」→「Gemini接続テスト」を押す。
8. 「通知へのアクセスを開く」→ LINE GPT PhoneをON。
9. 「ユーザー補助設定を開く」→ LINE GPT PhoneをON。
10. LINEの「よ」グループの通知・メッセージ内容表示をON。
11. 別の参加者から「@GPT こんにちは」と送信。

成功するとLINE画面が開き、自動返信します。

@Allについて:
「@GPT 全体メンションして」のような明示依頼を受けると、
LINE入力欄へ「@」を入力 → @All/全員候補をクリック → 本文を追加 → 送信、の順に動作します。
LINEのUIバージョン差で候補名が異なる場合は追加調整が必要です。

PCなしでAPKを再ビルドする方法:
GitHubのmainブランチへ同梱ZIPを更新すると、GitHub ActionsがAPKを自動生成します。
