LINE GPT Phone - スマホ単体版

この版はPC中継サーバーを使いません。

仕組み:
LINE通知
→ このAndroidアプリ
→ OpenAI Responses API
→ LINEアプリを開く
→ ユーザー補助機能で返信を入力・送信

初期設定:
対象グループ: よ
モデル: gpt-5.6-sol
呼び出し: @GPT / ＠GPT / GPT

重要:
・これはLINE OpenChat向けの公式Bot APIではありません。
・LINEアプリのUI変更により、自動入力/送信部分が壊れる可能性があります。
・このChatGPTの現在のセッションそのものを移すのではなく、同じモデルを使う別のAPIセッションです。
・OpenAI APIはChatGPT Plusとは別課金です。
・APIキーを他人へ送らないでください。

PCなしでAPKを作る方法（推奨）:
1. Androidに「Code on the Go」を公式サイトからインストール。
2. このZIPを解凍。
3. Code on the Goで line_gpt_phone_only フォルダをプロジェクトとして開く。
4. Gradle sync後、:app:assembleDebug を実行。
5. app/build/outputs/apk/debug/app-debug.apk をインストール。

もしプロジェクトを開いた際にGradle Wrapperを求められた場合:
Code on the Goの現在のツールチェーン（Gradle/AGP）でプロジェクトを開き直すか、
新規Javaプロジェクトを作成し、このZIPの app/src/main と app/build.gradle を移してください。

アプリをインストールした後:
1. LINE GPT Phoneを開く。
2. OpenAI APIキーを入力。
3. 対象グループが「よ」になっていることを確認。
4. 「設定を保存」。
5. 「OpenAI接続テスト」を押す。
6. 「通知へのアクセスを開く」→ LINE GPT PhoneをON。
7. 「ユーザー補助設定を開く」→ LINE GPT PhoneをON。
8. LINEの「よ」グループの通知・メッセージ内容表示をON。
9. 別の参加者から「@GPT こんにちは」と送信。

成功するとLINE画面が開き、自動返信します。

@Allについて:
この版では @All の候補UI選択まで実装済みです。
「@GPT 全体メンションして」のような明示依頼を受けると、
LINE入力欄へ「@」を入力 → @All/全員候補をクリック → 本文を追加 → 送信、の順に動作します。
LINEのUIバージョン差で候補名が異なる場合は追加調整が必要です。
