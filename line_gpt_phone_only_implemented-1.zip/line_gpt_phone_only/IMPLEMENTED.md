# 実装済み機能

- PC中継不要。Android端末から OpenAI Responses API に直接接続。
- APIキーは Android Keystore の AES/GCM 鍵で暗号化保存。
- 対象グループの初期値は「よ」。
- `@GPT` / `＠GPT` / `GPT` を含むLINE通知だけを処理。
- GPT-5.6 Sol (`gpt-5.6-sol`) を初期モデルに設定。
- 通常返信は Accessibility Service でLINE入力欄へ入力し送信。
- 「全体メンションして」「全員メンションして」「@Allして」等の明示依頼では、
  単なる `@All` 文字列ではなく、LINEのメンション候補UIを開いて `@All` / `全員` 候補を選択し、
  その後に本文を貼り付けて送信する状態機械を実装。
- 同一通知の15秒以内の重複処理を抑制。
- APIエラーはLINEへ誤送信しない。
- GitHub ActionsでAPKを自動ビルドできるワークフローを同梱。

## 制約

LINE OpenChat向け公式Bot APIではなく、通知アクセスとAccessibilityを利用する方式です。
LINEのUIや通知フォーマット変更により調整が必要になる可能性があります。
また、このChatGPTセッションそのものとAndroidアプリの間に直接コマンド経路はありません。
アプリ内のGPTはOpenAI API上の別セッションです。
