# 実装済み機能

- バージョン `0.3-gemini-free`。
- PC中継不要。Android端末から Google Gemini API に直接接続。
- カード登録なしで利用できる Gemini API 無料枠に対応。
- 初期モデルは `gemini-3.5-flash-lite`。
- Gemini APIキーは Android Keystore の AES/GCM 鍵で暗号化保存。
- 旧OpenAI版の保存キーを誤送信しないよう、Gemini用の別暗号化領域へ移行。
- アプリ内からGoogle AI StudioのAPIキー作成画面を開ける。
- 対象グループの初期値は「よ」。
- `@GPT` / `＠GPT` / `GPT` を含むLINE通知だけを処理。
- 通常返信は Accessibility Service でLINE入力欄へ入力し送信。
- 「全体メンションして」「全員メンションして」「@Allして」等の明示依頼では、
  LINEのメンション候補UIを開いて `@All` / `全員` 候補を選択し、本文を貼り付けて送信。
- 同一通知の15秒以内の重複処理を抑制。
- APIエラーはLINEへ誤送信しない。
- GitHub ActionsでAPKを自動ビルド。

## 制約

Gemini API無料枠には利用上限があります。また、無料枠へ送信した内容はGoogleの製品改善に
利用される場合があります。LINE公式Bot APIではなく通知アクセスとAccessibilityを使うため、
LINEのUIや通知フォーマット変更により調整が必要になる可能性があります。
